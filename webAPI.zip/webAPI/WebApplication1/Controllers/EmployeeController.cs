﻿using WebApplication1.Models;
using System;
using System.Web.Http;
using System.Net.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Web.Http.Cors;
using System.IO;
using Microsoft.AspNetCore.Http;
using System.Web;
using HttpContext = System.Web.HttpContext;
using System.Web.Http.Description;
using System.Text;

namespace WebApplication1.Controllers
{
    // A Customized API Methods
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class EmployeeController : ApiController
    {
         private SwaggerIntegrationContext db = new SwaggerIntegrationContext();

        [ResponseType(typeof(Employee))]
        [Route("api/GetAllEmployee")]
        [HttpGet]
        public HttpResponseMessage GetAllEmployee()
        {
            string qry = @"select [EmployeeId],[EmployeeName],[Department],
            convert(varchar(10),[DateOfJoining],120) as [DateOfJoining],PhotoFileName from dbo.Employee order by EmployeeId DESC";
            DataTable table = new DataTable();
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(qry, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                try
                {
                    da.Fill(table);
                }
                catch (Exception)
                {                  
                }                                                 
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [ResponseType(typeof(Employee))]
        [Route("api/getFilteredEmpList")]
        [HttpGet]
        public HttpResponseMessage getFilteredEmpList(string _field, string _searchText = null)
        {
            StringBuilder sb = new StringBuilder();
            if (_searchText is null)
            {
                sb.AppendLine("select [EmployeeId],[EmployeeName],[Department],");
                sb.AppendLine("convert(varchar(10),[DateOfJoining],120) as [DateOfJoining],PhotoFileName from dbo.Employee order by EmployeeId DESC");
            }
            else
            {
                sb.AppendLine("select [EmployeeId],[EmployeeName],[Department],");
                sb.AppendLine(" convert(varchar(10),[DateOfJoining],120) as [DateOfJoining],[PhotoFileName] from dbo.Employee");
                sb.AppendLine(" where " + _field.ToLower() + " LIKE '%" + _searchText.ToLower() + "%'");
                sb.AppendLine( "order by EmployeeId DESC");
            }

            DataTable table = new DataTable();
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(sb.ToString(), conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                try
                {
                    da.Fill(table);
                }
                catch (Exception)
                {
                }          
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }
        

        [ResponseType(typeof(Employee))]
        [Route("api/GetAllDepartmentNames")]
        [HttpGet]
        public HttpResponseMessage GetAllDepartmentNames()
        {
            string qry = @"select DepartmentName from dbo.Department";
            DataTable table = new DataTable();
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(qry, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                da.Fill(table);
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [ResponseType(typeof(Employee))]
        [Route("api/AddEmployee")]
        [HttpPost]
        public string AddEmployee(Employee emp)
        {
            try
            {
                string qry = @"insert into dbo.Employee values(
                        '" + emp.EmployeeName + @"'
                        ,'" + emp.Department + @"'
                        ,'" + emp.DateOfJoining + @"'
                        ,'" + emp.PhotoFileName + @"'
                        )";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully!";
            }
            catch (Exception)
            {
                return "Failure to Add!";
            }
        }

        [ResponseType(typeof(Employee))]
        [Route("api/UpdateEmployee")]
        [HttpPut]
        public string UpdateEmployee(Employee emp)
        {
            try
            {
                string qry = @"
                update dbo.Employee set 
                EmployeeName = '" + emp.EmployeeName + @"'
                ,Department = '" + emp.Department + @"'
                ,DateOfJoining = '" + emp.DateOfJoining + @"'
                ,PhotoFileName = '" + emp.PhotoFileName + @"'
                where EmployeeId = " + emp.EmployeeID + @"";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfully!";
            }
            catch (Exception)
            {
                return "Failure to Update!";
            }
        }

        [ResponseType(typeof(Employee))]
        public string Delete(int id)
        {
            try
            {
                string qry = @"delete from dbo.Employee where EmployeeID =" + id + @"";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfully!";
            }
            catch (Exception)
            {
                return "Failure to Delete!";
            }
        }

        [ResponseType(typeof(Employee))]
        [Route("api/SaveFile")]
        [HttpPost]
        public string SaveFile()
        {
            try
            {
                var httpRequest = HttpContext.Current.Request;
                var postedFile = httpRequest.Files[0];
                var filename = postedFile.FileName;
                string physicalPath = HttpContext.Current.Server.MapPath("~/Photos/" + filename);
                postedFile.SaveAs(physicalPath);
                return filename;
            }
            catch (Exception)
            {
                return "anonymous.png";
            }
        }
    }
}
