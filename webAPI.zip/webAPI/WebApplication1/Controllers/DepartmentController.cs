﻿
using WebApplication1.Models;
using System;
using System.Web.Http;
using System.Net.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Net;
using System.Web.Http.Cors;
using System.Web.Http.Description;

namespace WebApplication1.Controllers
{
    
    [EnableCors(origins: "*", headers: "*", methods: "*")]
    public class DepartmentController : ApiController
    {
        [ResponseType(typeof(Department))]
        public HttpResponseMessage Get()
        {
            string qry = @"select DepartmentId, DepartmentName from dbo.Department order by DepartmentId DESC";
            DataTable table = new DataTable();
            using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
            using (var cmd = new SqlCommand(qry, conn))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.CommandType = CommandType.Text;
                try
                {
                    da.Fill(table);
                }
                catch (Exception)
                {                  
                }
            }
            return Request.CreateResponse(HttpStatusCode.OK, table);
        }

        [ResponseType(typeof(Department))]
        public string Post(Department dep)
        {
            try
            {
                string qry = @"insert into dbo.Department values('" + dep.DepartmentName + @"')";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Added Successfully!";
            }
            catch (Exception ex)
            {
                return "Failure to Add!";
            }
        }

        [ResponseType(typeof(Department))]
        public string Put(Department dep)
        {
            try
            {
                string qry = @"update dbo.Department set DepartmentName = '" + dep.DepartmentName + @"'where DepartmentID =" + dep.DepartmentID + @"";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Updated Successfully!";
            }
            catch (Exception)
            {
                return "Failure to Update!";
            }
        }

        [ResponseType(typeof(Department))]
        public string Delete(int id)
        {
            try
            {
                string qry = @"delete from dbo.Department where DepartmentID =" + id + @"";
                DataTable table = new DataTable();
                using (var conn = new SqlConnection(ConfigurationManager.ConnectionStrings["EmployeeAppDB"].ConnectionString))
                using (var cmd = new SqlCommand(qry, conn))
                using (var da = new SqlDataAdapter(cmd))
                {
                    cmd.CommandType = CommandType.Text;
                    da.Fill(table);
                }
                return "Deleted Successfully!";
            }
            catch (Exception)
            {
                return "Failure to Delete!";
            }
        }
    }
}
