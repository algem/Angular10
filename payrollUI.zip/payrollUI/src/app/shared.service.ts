import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of} from 'rxjs'
import { catchError, retry } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class SharedService {
   UploadPhoto(formData: FormData) {
    throw new Error('Method not implemented.');
  }
  readonly APIUrl =   "http://localhost:50976/api";
  readonly PhotoUrl = "http://localhost:50976/Photos/";


 
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/x-www-form-urlencoded',
      'Access-Control-Allow-Origin':  '*',
      'Accept': 'applcation/ json'
    })
};
log:any;
  
  constructor(private http: HttpClient) { }
  
  handleError<T>({ operation = 'operation', result }: { operation?: string; result?: T; } = {}) {
    type NewType = Observable<T>;
    return (error: any): NewType => {
      console.error(error);
      this.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
  
  // Department----------
  getDepList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+'/department');
  }
  addDepartment(val:any){
    return this.http.post(this.APIUrl+'/department/',val);
  }
  updateDepartment(val:any){
    return this.http.put(this.APIUrl+'/department/',val);
  }
  deleteDepartment(val:any){
    return this.http.delete(this.APIUrl+'/department/'+ val);
  }

  // Employee-------------
  getFilteredEmpList(selectedColumn: string, searchText: string):Observable<any[]>{
    const params = new HttpParams()
    .set('_field', selectedColumn)
    .set('_searchText', searchText);  
    return this.http.get<any>(this.APIUrl+ '/getFilteredEmpList/', {params: params});
  }

  getEmpList():Observable<any[]>{
    return this.http.get<any>(this.APIUrl+ '/GetAllEmployee/');
  }

  addEmployee(val:any){
    return this.http.post(this.APIUrl+'/AddEmployee/',val);
  }
  updateEmployee(val:any){
    return this.http.put(this.APIUrl+'/UpdateEmployee/',val);
  }
  deleteEmployee(val:any){
    return this.http.delete(this.APIUrl+'/employee/' + val);
  }
  uploadPhoto(val:any){    
    return this.http.post(this.APIUrl+'/SaveFile/', val);
  }
  getAllDepartmentName():Observable<any[]>{
    return this.http.get<any[]>(this.APIUrl + '/GetAllDepartmentNames/');
  }
}
