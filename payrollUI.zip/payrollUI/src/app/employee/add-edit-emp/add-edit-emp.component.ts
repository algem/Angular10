import { ThisReceiver } from '@angular/compiler';
import { Component, Input, OnInit } from '@angular/core';
import { SharedService } from 'src/app/shared.service';
import Swal from 'sweetalert2'
@Component({
  selector: 'app-add-edit-emp',
  templateUrl: './add-edit-emp.component.html',
  styleUrls: ['./add-edit-emp.component.css']
})
export class AddEditEmpComponent implements OnInit {
 
 
constructor(private service:SharedService) { }
 
  @Input() emp:any;
  EmployeeId!: string;
  EmployeeName!: string;
  Department!:string;
  DateOfJoining!:string;
  PhotoFileName!:string;
  PhotoFilePath!:string;
  DepartmentsList!:any[];
  ngOnInit(): void {
    this.loadDepartmentList();   
  }

  loadDepartmentList(){  
    this.service.getAllDepartmentName().subscribe((data:any)=>{
      this.DepartmentsList = data;
      this.EmployeeId = this.emp.EmployeeId;
      this.EmployeeName = this.emp.EmployeeName;
      this.Department=this.emp.Department;
      this.DateOfJoining=this.emp.DateOfJoining;
      this.PhotoFileName=this.emp.PhotoFileName;    
      this.PhotoFilePath=this.service.PhotoUrl+ this.PhotoFileName;
      this.emp.PhotoFilePath = this.PhotoFilePath;
    });
  }

  addEmployee(){
    if (this.EmployeeName === '') {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Employee Name is required!',
      })  
      return;
    }
    if (this.Department === '') {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Select Department!',
      })  
      return;
    }
    if (this.Department === '--Select--') {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Select Department!',
      })  
      return;
    }
    if (this.DateOfJoining === '') {
      Swal.fire({
        icon: 'error',
        title: 'Oops...',
        text: 'Date of Joining required!',
      })  
      return;
    }
    var val = {
      EmployeeId:this.EmployeeId,
      EmployeeName:this.EmployeeName,
      Department:this.Department,
      DateOfJoining:this.DateOfJoining,
      PhotoFileName:this.PhotoFileName     
    };    
      this.service.addEmployee(val).subscribe(res=>{
      Swal.fire(res.toString());
     
    });
  }

  updateEmployee(){
    var val ={     
      EmployeeId:this.EmployeeId,
      EmployeeName:this.EmployeeName,
      Department:this.Department,
      DateOfJoining:this.DateOfJoining,
      PhotoFileName:this.PhotoFileName};
      this.service.updateEmployee(val).subscribe(res=>{   
      Swal.fire(res.toString());
  
    });
  }
 
  refreshDepList(){
    this.service.getDepList().subscribe(data=>{
      this.DepartmentsList = data;    
      this.EmployeeId = this.emp.EmployeeId;
      this.EmployeeName = this.emp.EmployeeName;
      this.Department=this.emp.Department;
      this.DateOfJoining=this.emp.DateOfJoining;
      this.PhotoFileName=this.emp.PhotoFileName;
      this.PhotoFilePath=this.service.PhotoUrl+ this.PhotoFileName;
    });
  }

  uploadPhoto(event:any){
    let item: any;
    var file=event.target.files[0];
    const formData:FormData = new FormData();
    formData.append('uploadedFile',file, file.name);   
    this.service.uploadPhoto(formData).subscribe((data:any) => { 
      this.PhotoFileName = data.toString();
      this.PhotoFilePath = this.service.PhotoUrl+ this.PhotoFileName; 
      
    })
   
  }
}



