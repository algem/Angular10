export class Department {
    'DepartmentID': bigint;
    'DepartmentName': string;
}
