export class Employee {
    'EmployeeID': bigint;
    'EmployeeName': string;
    'Department': string;
    'DateOfJoining': Date;
    'ProtoFileName': string;
}
